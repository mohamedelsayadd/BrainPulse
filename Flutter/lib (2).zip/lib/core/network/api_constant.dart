class ApiConstant {
  static const baseUrl = 'https://manoehab-001-site1.ltempurl.com/api/';
  static const sendDataByDoctor = 'AIModel/predict';
  static const getAllPatients = 'Patients';
  static const addPatient = 'Patients';
  static const deletePatient = 'Patients/{id}';
}
