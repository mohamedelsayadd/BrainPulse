
// import 'package:brain_pulse/features/home/presentation/screens/widgets/drop_file_body.dart';
// import 'package:flutter/material.dart';

// class DropFileScreen extends StatelessWidget {
//   const DropFileScreen({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return const DropFileBody();
//   }
// }
