// import 'package:json_annotation/json_annotation.dart';

// part 'send_point_response_model.g.dart';

// @JsonSerializable()
// class SendPointResponseModel {
//   predictionData? prediction;

//   SendPointResponseModel({this.prediction});
//   factory SendPointResponseModel.fromJson(Map<String, dynamic> json) =>
//       _$SendPointResponseModelFromJson(json);

//   Map<String, dynamic> toJson() => _$SendPointResponseModelToJson(this);
// }

// @JsonSerializable()
// class predictionData {
//   String? gpd;
//   String? grda;
//   String? lpd;
//   String? lrda;
//   String? other;
//   String? seizure;
//   String? predictedClass;

//   predictionData(
//       {this.gpd,
//       this.grda,
//       this.lpd,
//       this.lrda,
//       this.other,
//       this.seizure,
//       this.predictedClass});

//   factory predictionData.fromJson(Map<String, dynamic> json) =>
//       _$predictionDataFromJson(json);

//   Map<String, dynamic> toJson() => _$predictionDataToJson(this);
// }
