import 'package:brain_pulse/core/Widgets/profile_text_field.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';


class EditMyProfileWidget extends StatelessWidget {


  @override
  Widget build(BuildContext context) {
    return ProfileTextField();
  }
}
