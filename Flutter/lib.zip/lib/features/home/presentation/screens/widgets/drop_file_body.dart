
// import 'dart:ffi';

// import 'package:brain_pulse/core/Theming/colors.dart';
// import 'package:brain_pulse/features/home/presentation/screens/widgets/custom_button.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_screenutil/flutter_screenutil.dart';

// class DropFileBody extends StatelessWidget {
//   const DropFileBody({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: Theme.of(context).scaffoldBackgroundColor,
//       body: SafeArea(
//           child: Column(
//         children: [
//           Padding(
//             padding: const EdgeInsets.only(top: 100, left: 15, right: 15),
//             child: Container(
//               width: double.infinity,
//               height: 300.h,
//               decoration: BoxDecoration(
//                   color: ColorsApp.grey300,
//                   borderRadius: BorderRadius.circular(15.r)),
//             ),
//           ),
//           Padding(
//             padding: EdgeInsets.symmetric(vertical: 30.h, horizontal: 20.w),
//             child: CustomButton(
//               text: "Send File",
//               onTap: () {},
//               width: double.infinity,
//               height: 80.h,
//             ),
//           ),
//           Padding(
//             padding: EdgeInsets.symmetric(vertical: 5.h, horizontal: 20.w),
//             child: CustomButton(
//               text: "Cancel",
//               onTap: () {
//                 Navigator.pop(context);
//               },
//               width: double.infinity,
//               height: 80.h,
//             ),
//           )
//         ],
//       )),
//     );
//   }
// }
