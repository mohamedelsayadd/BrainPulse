
import 'package:brain_pulse/features/home/presentation/screens/widgets/get_image_body.dart';
import 'package:flutter/material.dart';

class GetImageScreen extends StatelessWidget {
  const GetImageScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const GetImageBody();
  }
}
