
import 'package:brain_pulse/features/home/presentation/screens/widgets/data_eeg_body.dart';
import 'package:flutter/material.dart';

class EegDataScreen extends StatelessWidget {
  const EegDataScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return DataEegBody();
  }
}
