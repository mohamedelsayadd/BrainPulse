class Routes {
  static const String offline = '/offline';

  static const String splashScreen = '/splashScreen';
  static const String onBoarding = '/onBoarding';
  static const String loginScreen = '/loginScreen';
  static const String appNavigation = '/appnavigation';
  static const String homeScreen = '/homeScreen';
  static const String getiamge = '/getimage';
  static const String eegdata = '/eegdata';
  static const String getImage = '/getimage';
  static const String dataByDoctorScreen = '/DataByDoctorScreen';
  static const String dropfilescreen = '/dropfilescreen';
  static const String editProfileScreen = '/EditProfileScreen';
  static const String privacyAndSecurity = '/PrivacyAndSecurity';
  static const String changePasswordScreen = '/ChangePasswordScreen';
  static const String deleteAccount = '/DeleteAccount';
  static const String displayData = '/DisplayData';
  static const String thememode = '/themedata';
}
