class SharedPrefKeys {
  static const String token = "token";
  static const String email = "email";
  static const String name = "name";
  static const String phoneNumber = "phoneNumber";
  static const String firstName = "firstName";
  static const String userId = "id";
}
